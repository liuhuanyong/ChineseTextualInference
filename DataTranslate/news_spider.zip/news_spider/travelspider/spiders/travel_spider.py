# coding=utf-8
import scrapy
import pymongo
from lxml import etree
from travelspider.items import TravelspiderItem
import os

class BuildData:
    def __init__(self):
        cur = '/'.join(os.path.abspath(__file__).split('/')[:-1])
        self.sent_filepath = os.path.join(cur, 'sent_all.txt')

    def create_urls(self):
        conn = pymongo.MongoClient()
        urls = []
        for i in conn['nli']['translate'].find({'flag':0}):
            urls.append(i['url'])
        #urls = ['http://www.iciba.com/{}'.format(query.strip()) for query in open(self.sent_filepath) if query.strip()]
        return urls

class TravelSpider(scrapy.Spider):
    name = 'travel'
    '''资讯采集主控函数'''
    def start_requests(self):
        Data = BuildData()
        urls = Data.create_urls()
        for url in urls:
            try:
                print(url)
                english = url.replace('http://www.iciba.com/', '')
                param = {'url': url, 'english': english}
                yield scrapy.Request(url=url, meta=param, callback=self.page_parser, dont_filter=True)
            except:
                pass

    '''网页解析'''
    def page_parser(self, response):
        selector = etree.HTML(response.text)
        try:
            chinese = selector.xpath('//div[@class="in-base"]/div/div/text()')[0]
        except Exception as e:
            chinese = response.meta['english']
        item = TravelspiderItem()
        item['url'] = response.meta['url']
        item['english'] = response.meta['english']
        item['chinese'] = chinese
        if item['english'] == item['chinese']:
            item['flag'] = 0
        else:
            item['flag'] = 1
        yield item
        return
